package com.cg.StudentRepository.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Activity")
public class Activity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long actId;
	private String info;
	private String deadline;

	public Activity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Activity(Long actId, String info, String deadline) {
		super();
		this.actId = actId;
		this.info = info;
		this.deadline = deadline;
	}

	public Long getActId() {
		return actId;
	}

	public void setActId(Long actId) {
		this.actId = actId;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getDeadline() {
		return deadline;
	}

	public void setDeadline(String deadline) {
		this.deadline = deadline;
	}

	@Override
	public String toString() {
		return "Activity [actId=" + actId + ", info=" + info + ", deadline=" + deadline + "]";
	}

}
