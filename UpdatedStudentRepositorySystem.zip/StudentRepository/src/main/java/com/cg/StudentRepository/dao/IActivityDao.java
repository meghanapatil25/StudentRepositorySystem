package com.cg.StudentRepository.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.StudentRepository.bean.Activity;

@Repository
public interface IActivityDao extends JpaRepository<Activity, Long> {

}
