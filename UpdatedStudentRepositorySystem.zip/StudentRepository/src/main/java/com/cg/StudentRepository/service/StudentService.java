package com.cg.StudentRepository.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.StudentRepository.bean.Student;
import com.cg.StudentRepository.dao.IStudentDao;



@Service
public class StudentService{
	
	@Autowired
	IStudentDao studentdao;

	public Student addStudent(Student student) {
		return studentdao.save(student);
	}
	
	public Student validateStudent(String username,String password) {
		  return studentdao.validateStudent(username,password); 
	}
	
	public List<Student> getAllStudents(){
		return studentdao.getAllstudents();
	}

	public List<Student> getAllAdmins(){
		return studentdao.getAllAdmins();
	}
	
	public void deleteStudent(Long studentid) {
		studentdao.deleteById(studentid);
	}
	
	
	public Student validateForOtp(Long studentid, String mobile){
		return studentdao.validateForOtp(studentid, mobile);
	}
	
	public Student getStudentById(Long studentid) {
		return studentdao.getStudentById(studentid);
	}
	
	public Student getAdminById(Long studentid) {
		return studentdao.getAdminById(studentid);
	}

	public void updateStudent(String email, String mobile, Long studentid) {
		studentdao.updateStudent(email, mobile, studentid);
	}
	
	public Student checkUniqueUsername(String username) {
		return studentdao.checkUniqueUsername(username);
	}
	
	public void updatePassword(Long studentid, String password, String confirmPassword) {
		 studentdao.updatePassword(studentid, password, confirmPassword);
	}

}
