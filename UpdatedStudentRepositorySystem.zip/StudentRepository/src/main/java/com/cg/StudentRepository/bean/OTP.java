package com.cg.StudentRepository.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="OTP")
public class OTP {

	@Id
	private String id;
	private String number;
	private String otp;
	private Long studentid;
	public OTP(String id, String number, String otp, Long studentid) {
		super();
		this.id = id;
		this.number = number;
		this.otp = otp;
		this.studentid = studentid;
	}
	public OTP() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public Long getStudentid() {
		return studentid;
	}
	public void setStudentid(Long studentid) {
		this.studentid = studentid;
	}
	@Override
	public String toString() {
		return "OTP [id=" + id + ", number=" + number + ", otp=" + otp + ", studentid=" + studentid + "]";
	}
	
	
}
