package com.cg.StudentRepository.controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.StudentRepository.bean.Activity;
import com.cg.StudentRepository.bean.Student;
import com.cg.StudentRepository.service.ActivityService;
import com.cg.StudentRepository.service.SmsService;
import com.cg.StudentRepository.service.StudentService;

@Controller
public class StudentController {

	@Autowired
	private StudentService studentservice;
	
	@Autowired
	private ActivityService activityservice;

	Long studentid ;
	String username = null;


	@RequestMapping("/")
	public String index() {
		return "index";
	}

	@RequestMapping(value = { "/home" })
	public ModelAndView home(@ModelAttribute("Student") Student student) {

		return new ModelAndView("login", "student", student);
	}


	//Login for User(Admin student and superadmin)
	@RequestMapping(value = "loginUser", method = RequestMethod.POST)
	public ModelAndView loginUser(@ModelAttribute("Student") Student student, Map<String, Object> model) {

		Student studentList = studentservice.validateStudent(student.getUsername(), student.getPassword());
		String role=null;
		if (studentList == null) {
			model.put("InvalidUser", true);
			return new ModelAndView("login");		
		} else {
			model.put("InvalidUser", false);
			
			role=studentList.getRole();
			username=studentList.getUsername();
			studentid=studentList.getStudentid();
			
			model.put("studentid", studentList.getStudentid());
			model.put("username", studentList.getUsername());
			
			if ("Admin".equalsIgnoreCase(role)) {
	            return new ModelAndView("AdminLanding");
	        } else if ("Student".equalsIgnoreCase(role)) {
	            return new ModelAndView("StudentLanding");
	        } else if("Superadmin".equalsIgnoreCase(role)){
	        	return new ModelAndView("SuperAdminLanding");
	        }
			return new ModelAndView("login", "student", student);	
		}
	}
	
	//Sign up for students
	@RequestMapping(value = { "/signup" })
	public String signup(@ModelAttribute("Student") Student student, Map<String, Object> model) {
		
		model.put("addNewStudent", true);
		return "signup";
	}

	@RequestMapping(value = "/success")
	public ModelAndView success(@ModelAttribute("Student") Student student, Map<String, Object> model, HttpSession session) {
		student.setRole("Student");
		if (studentservice.checkUniqueUsername(student.getUsername()) == null) {
			if (studentservice.addStudent(student) != null) {
				
				/* session.setAttribute("username", student.getUsername()); */
				model.put("studentAdded", true);
				model.put("studentid", student.getStudentid());
				model.put("username", student.getUsername());
				model.put("addNewStudent", false);
				return new ModelAndView("signup", "Student", student);
			} else {
				model.put("addNewStudent", true);
				model.put("studentAdded", false);
				return new ModelAndView("signup", "Student", student);
			}
		}
		model.put("addNewStudent", true);
		model.put("studentAdded", false);
		return new ModelAndView("signup", "Student", student);
	}

	
	@RequestMapping(value="signupToHome")
	public String signupTohome(){
		return "index";
	}
	
	//student Module
	@RequestMapping(value = "viewProfile", method = RequestMethod.GET)
	public ModelAndView viewProfile(@RequestParam("studentid") Long studentid, Map<String, Object> model) {
		model.put("viewProfile", true);
		model.put("editProfile", false);
		model.put("studentid", studentid);
		Student student = studentservice.getStudentById(studentid);
		model.put("username", student.getUsername());
		return new ModelAndView("StudentLanding", "student", student);
	}

	@RequestMapping(value = "editProfile", method = RequestMethod.GET)
	public ModelAndView editProfile(@RequestParam("studentid") Long studentid,
			@ModelAttribute("Student") Student student, Map<String, Object> model) {
		model.put("viewProfile", false);
		model.put("editProfile", true);
		model.put("studentid", studentid);
		Student student1 = studentservice.getStudentById(studentid);
		model.put("username", student1.getUsername());
		return new ModelAndView("StudentLanding", "Student1", student1);
	}

	@RequestMapping(value = "update", method = RequestMethod.POST)
	public ModelAndView update(@ModelAttribute("Student") Student student,
			@RequestParam(value = "studentid", required = false) Long studentid, Map<String, Object> model) {
		model.put("viewProfile", false);
		model.put("editProfile", false);
		model.put("studentid", studentid);
		studentservice.updateStudent(student.getEmail(), student.getMobile(), studentid);
		model.put("updateSuccess", true);
		model.put("username", student.getUsername());
		return new ModelAndView("StudentLanding", "Student", student);
	}
	
	@RequestMapping(value="showActivities",method=RequestMethod.GET)
	public ModelAndView showActivity(@RequestParam("studentid")Long studentid,  @ModelAttribute("Activity") Activity activity, Map<String, Object> model) {
		model.put("showAct",true);
		List<Activity> actList = activityservice.showAllActivities();
		
		if(actList.isEmpty()) {
			model.put("studentid", studentid);
			model.put("IsEmpty", true);
			return new ModelAndView("StudentLanding","actList",actList);
        }
		else
		{
			model.put("studentid", studentid);
			model.put("IsEmpty",false);		
			return new ModelAndView("StudentLanding","actList",actList);
		}
	}

	@RequestMapping(value = "clickApply")
	public ModelAndView apply(@ModelAttribute("Student") Student student) {
		Student s=studentservice.getStudentById(studentid); 
		return new ModelAndView("JobApply","Student",s);
	}
	
	@RequestMapping(value = "studentLogout")
	public ModelAndView studentLogout(@ModelAttribute("Student") Student student) {
		username = null;
		return new ModelAndView("login", "student", student);
	}
	
	
	//Admin Module
	@RequestMapping(value="viewAllStudents", method=RequestMethod.GET)
	public ModelAndView viewAllStudents(@ModelAttribute("Student") Student student, Map<String, Object> model) {
		List<Student> Liststudent=studentservice.getAllStudents();
		if (Liststudent.isEmpty()) {
            model.put("IsEmpty", true);
            return new ModelAndView("AdminLanding","Liststudent",Liststudent);
        }
		else
		{
			model.put("IsEmpty",false);
			return new ModelAndView("AdminLanding","Liststudent",Liststudent);
		} 	
	}
		
	@RequestMapping(value="deleteStudent")
	public ModelAndView deleteStudent(@ModelAttribute("Student") Student student, Map<String, Object> model){
		model.put("username",student.getUsername());
		model.put("EnterIdToDelete", true);
		return new ModelAndView("AdminLanding");	
	}
	
	@RequestMapping(value="delete", method=RequestMethod.POST)
	public ModelAndView delete(@ModelAttribute("Student") Student student, Map<String, Object> model) {

		if(studentservice.getStudentById(student.getStudentid())!=null) {
			model.put("username",student.getUsername());
			studentservice.deleteStudent(student.getStudentid());
			model.put("EnterIdToDelete", false);
			return new ModelAndView("AdminLanding","Student",student);
			
		}else {	
			model.put("username",student.getUsername());
			model.put("InvalidID",true);
			model.put("EnterIdToDelete", true);
			return new ModelAndView("AdminLanding","Student",student);
		}
	}
	
	@RequestMapping(value="addNewActivity",method=RequestMethod.GET)
	public ModelAndView addNewActivity(@ModelAttribute("Activity") Activity activity, Map<String, Object> model) {
		model.put("addNewAct",true);
		return new ModelAndView("AdminLanding");
	}
	
	@RequestMapping(value="activityAdded", method=RequestMethod.POST)
	public ModelAndView addActivity(@ModelAttribute("Activity") Activity activity, Map<String, Object> model) {
		Activity act = activityservice.addActivity(activity);	
		
		SmsService smsservice = new SmsService();
		List<Student> students= studentservice.getAllStudents();	
		
		for(Student s : students) {
			smsservice.sendSms(s.getMobile(), "Dear "+s.getName()+",\nThis is to notify you of recent activity on your account. \n'"+act.getInfo()+"' Activity is newly added. Please check before deadline "+act.getDeadline()+". ");
		}
		model.put("addedAct", true);		
		return new ModelAndView("AdminLanding","Activity",activity);
	}

	@RequestMapping(value="showAllActivities",method=RequestMethod.GET)
	public ModelAndView showActivities(@ModelAttribute("Activity") Activity activity, Map<String, Object> model) {
		model.put("showAct",true);
		List<Activity> actList = activityservice.showAllActivities();
		
		if(actList.isEmpty()) {
			model.put("IsEmptyAct", true);
			return new ModelAndView("AdminLanding","actList",actList);
        }
		else{
			model.put("IsEmptyAct",false);		
			return new ModelAndView("AdminLanding","actList",actList);
		}
	}
	
	@RequestMapping(value="removeActivity",method=RequestMethod.GET)
	public String removeActivity(@RequestParam("actId") Long actId, Map<String, Object> model) {
		activityservice.removeActivityById(actId);
		return "redirect:/showAllActivities";
	}

	
	@RequestMapping(value = "adminLogout")
	public ModelAndView adminLogout(@ModelAttribute("Student") Student student) {
		username = null;
		return new ModelAndView("login", "student", student);
	}

	//SuperAdmin Module
	@RequestMapping(value="viewAllAdmin", method=RequestMethod.GET)
	public ModelAndView viewAllAdmin(Map<String, Object> model) {
		List<Student> ListAdmin=studentservice.getAllAdmins();
		if (ListAdmin.isEmpty()) {
            model.put("IsEmpty", true);
            return new ModelAndView("SuperAdminLanding","ListAdmin",ListAdmin);
        }
		else
		{
			model.put("IsEmpty",false);		
			return new ModelAndView("SuperAdminLanding","ListAdmin",ListAdmin);
		} 	
		
	}
	
	@RequestMapping(value="deleteAdmin",method=RequestMethod.GET)
	public ModelAndView deleteAdmin(@ModelAttribute("Student") Student student,Map<String, Object> model) {
		model.put("EnterIdToDelete", true);
		return new ModelAndView("SuperAdminLanding");
	}
	
	@RequestMapping(value="deleteadmin", method=RequestMethod.POST)
	public ModelAndView deleteadmin(@ModelAttribute("Student") Student student, Map<String, Object> model) {

		if(studentservice.getAdminById(student.getStudentid())!=null) {
			model.put("username",student.getUsername());
			studentservice.deleteStudent(student.getStudentid());
			model.put("EnterIdToDelete", false);
			return new ModelAndView("SuperAdminLanding","Student",student);
			
		}else {	
			model.put("username",student.getUsername());
			model.put("InvalidID",true);
			model.put("EnterIdToDelete", true);
			return new ModelAndView("SuperAdminLanding","Student",student);
		}
	}

	@RequestMapping(value="addAdmin", method=RequestMethod.GET)
	public ModelAndView admin(@ModelAttribute("Student") Student student, Map<String, Object> model) {
		model.put("addNewAdmin", true);
		return new ModelAndView("SuperAdminLanding","Student",student);
	}
	
	@RequestMapping(value = "adminSuccess", method=RequestMethod.POST)
	public ModelAndView adminSuccess(@ModelAttribute("Student") Student student, Map<String, Object> model) {
		student.setRole("Admin");
		if (studentservice.checkUniqueUsername(student.getUsername()) == null) {
			if (studentservice.addStudent(student) != null) {
				model.put("adminAdded", true);
				model.put("studentid", student.getStudentid());
				model.put("username", student.getUsername());
				model.put("addNewAdmin", false);
				return new ModelAndView("SuperAdminLanding", "Student", student);
			} else {
				model.put("adminAdded", false);
				return new ModelAndView("SuperAdminLanding", "Student", student);
			}
		}
		model.put("adminAdded", false);
		return new ModelAndView("SuperAdminLanding", "Student", student);
	}
	
	@RequestMapping(value="superAdminLogout")
	public ModelAndView superAdminLogout(@ModelAttribute("Student") Student student) {
		username = null;
		return new ModelAndView("login", "student", student);
	}
	
	@RequestMapping(value="applied")
	public String appliedSuccess() {
		 return "success";
	}
	
}
