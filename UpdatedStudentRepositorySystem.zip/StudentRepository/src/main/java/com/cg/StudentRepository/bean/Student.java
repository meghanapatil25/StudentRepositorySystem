
package com.cg.StudentRepository.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Student")
public class Student {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long studentid;
	private String name;
	private String address;
	private String city;
	private int pincode;
	private String state;
	private String country;
	private String dob;
	private int age;
	private String email;
	private String mobile;
	private String gender;
	private String specialization;
	
	@Column(unique = true)
	private String username;
	
	private String password;
	private String confirmPassword;
	private String role;
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Student(Long studentid, String name, String address, String city, int pincode, String state, String country,
			String dob, int age, String email, String mobile, String gender, String specialization, String username,
			String password, String confirmPassword, String role) {
		super();
		this.studentid = studentid;
		this.name = name;
		this.address = address;
		this.city = city;
		this.pincode = pincode;
		this.state = state;
		this.country = country;
		this.dob = dob;
		this.age = age;
		this.email = email;
		this.mobile = mobile;
		this.gender = gender;
		this.specialization = specialization;
		this.username = username;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.role = role;
	}


	public Long getStudentid() {
		return studentid;
	}


	public void setStudentid(Long studentid) {
		this.studentid = studentid;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public int getPincode() {
		return pincode;
	}


	public void setPincode(int pincode) {
		this.pincode = pincode;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public String getCountry() {
		return country;
	}


	public void setCountry(String country) {
		this.country = country;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getSpecialization() {
		return specialization;
	}


	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getConfirmPassword() {
		return confirmPassword;
	}


	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	@Override
	public String toString() {
		return "Student [studentid=" + studentid + ", name=" + name + ", address=" + address + ", city=" + city
				+ ", pincode=" + pincode + ", state=" + state + ", country=" + country + ", dob=" + dob + ", age=" + age
				+ ", email=" + email + ", mobile=" + mobile + ", gender=" + gender + ", specialization="
				+ specialization + ", username=" + username + ", password=" + password + ", confirmPassword="
				+ confirmPassword + ", role=" + role + "]";
	}

}
