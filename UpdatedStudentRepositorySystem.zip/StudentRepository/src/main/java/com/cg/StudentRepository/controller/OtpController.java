package com.cg.StudentRepository.controller;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.StudentRepository.bean.OTP;
import com.cg.StudentRepository.bean.Student;
import com.cg.StudentRepository.service.SmsService;
import com.cg.StudentRepository.service.StudentService;


@Controller
@RequestMapping(value="otp")
public class OtpController {
	
	@Autowired
	StudentService studentservice;
	
	private Map<String, OTP> otp_data = new HashMap<>();
	
	@RequestMapping(value = { "/forgotPassword" })
	public ModelAndView forgotPassword(@ModelAttribute("Student") Student student, Map<String, Object> model) {
		model.put("EnterMobile", true);
		model.put("EnterOtpToVerify",false);
		return new ModelAndView("forgotPassword");
	}
	
	@RequestMapping(value="sendOtp", method=RequestMethod.POST)
	public ModelAndView sendOtp(@ModelAttribute("Student") Student student, @ModelAttribute("OTP") OTP otp, Map<String, Object> model,HttpSession session) {
		otp=new OTP();
		Student s=studentservice.validateForOtp(student.getStudentid(),student.getMobile());
		if(s!=null) {
			session.setAttribute("studentid", s.getStudentid());
			otp.setNumber(student.getMobile());
			otp.setOtp(String.valueOf(((int)(Math.random()*(10000-1000)))+1000));
			otp.setStudentid(student.getStudentid());

			otp_data.put(student.getMobile(),otp);
			
			SmsService smsservice = new SmsService();
			smsservice.sendSms(otp.getNumber(), "Your OTP is : "+otp.getOtp());
			model.put("sendSuccess", true);
			model.put("EnterOtpToVerify",true);
			return new ModelAndView("forgotPassword");
		}else
		{
			model.put("EnterMobile",true);
			model.put("InvalidUser",true);
			return new ModelAndView("forgotPassword");
		}
		
	}
	
	@RequestMapping(value="verifyOtp",method=RequestMethod.POST)
	public ModelAndView verifyOtp(@ModelAttribute("OTP") OTP otp, Map<String, Object> model,HttpSession session) {
		Long l=(Long)session.getAttribute("studentid");
		Student student = studentservice.getStudentById(l);
		if(otp_data.containsKey(student.getMobile())) {
			OTP otp1=otp_data.get(student.getMobile());
			if(otp1!=null) 
			{
				if(otp.getOtp().equals(otp1.getOtp())) {
					otp_data.clear();
					model.put("VerifiesSuccess",true);
					model.put("changePassword",true);
					return new ModelAndView("forgotPassword","Student",student);
				}
			}
		}
		return new ModelAndView("forgotPassword","OTP",otp);		
	}
	
	@RequestMapping(value="changePassword",method=RequestMethod.POST)
	public ModelAndView changePassword(@ModelAttribute("Student") Student student, Map<String, Object> model,HttpSession session) {
		Long l=(Long)session.getAttribute("studentid");
		studentservice.updatePassword(l,student.getPassword(), student.getConfirmPassword());
		model.put("changePassword",true);
		model.put("updatePassSuccessfull", true);
		return new ModelAndView("forgotPassword","Student",student);		
	}
	
}
