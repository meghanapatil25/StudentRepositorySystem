package com.cg.StudentRepository.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.StudentRepository.bean.Activity;
import com.cg.StudentRepository.dao.IActivityDao;

@Service
public class ActivityService {
	
	@Autowired
	IActivityDao activitydao;

	public Activity addActivity(Activity activity) {
		return activitydao.save(activity);
	}
	
	public List<Activity> showAllActivities(){
		return activitydao.findAll();
	}
	
	public void removeActivityById(Long actId) {
		activitydao.deleteById(actId);
	}
}
